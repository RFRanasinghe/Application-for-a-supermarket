﻿
namespace System_for_a_food_city.cs
{
    partial class Cashier_1_Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtcno1 = new System.Windows.Forms.Label();
            this.txteaddress1 = new System.Windows.Forms.Label();
            this.txtcname1 = new System.Windows.Forms.TextBox();
            this.txtCashier1Number = new System.Windows.Forms.TextBox();
            this.txtCashier1Email = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnItemsBack = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtcid1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(240, 378);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 39);
            this.label1.TabIndex = 21;
            this.label1.Text = "Cashier Name";
            // 
            // txtcno1
            // 
            this.txtcno1.AutoSize = true;
            this.txtcno1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcno1.Location = new System.Drawing.Point(232, 440);
            this.txtcno1.Name = "txtcno1";
            this.txtcno1.Size = new System.Drawing.Size(224, 39);
            this.txtcno1.TabIndex = 22;
            this.txtcno1.Text = "Contact number";
            // 
            // txteaddress1
            // 
            this.txteaddress1.AutoSize = true;
            this.txteaddress1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txteaddress1.Location = new System.Drawing.Point(252, 502);
            this.txteaddress1.Name = "txteaddress1";
            this.txteaddress1.Size = new System.Drawing.Size(196, 39);
            this.txteaddress1.TabIndex = 23;
            this.txteaddress1.Text = "Email address";
            // 
            // txtcname1
            // 
            this.txtcname1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcname1.Location = new System.Drawing.Point(513, 378);
            this.txtcname1.Name = "txtcname1";
            this.txtcname1.Size = new System.Drawing.Size(509, 45);
            this.txtcname1.TabIndex = 24;
            // 
            // txtCashier1Number
            // 
            this.txtCashier1Number.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCashier1Number.Location = new System.Drawing.Point(513, 440);
            this.txtCashier1Number.Name = "txtCashier1Number";
            this.txtCashier1Number.Size = new System.Drawing.Size(509, 45);
            this.txtCashier1Number.TabIndex = 25;
            // 
            // txtCashier1Email
            // 
            this.txtCashier1Email.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCashier1Email.Location = new System.Drawing.Point(513, 499);
            this.txtCashier1Email.Name = "txtCashier1Email";
            this.txtCashier1Email.Size = new System.Drawing.Size(509, 45);
            this.txtCashier1Email.TabIndex = 26;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.BurlyWood;
            this.button3.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(239, 579);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(291, 78);
            this.button3.TabIndex = 27;
            this.button3.Text = "Cancel";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Tan;
            this.button4.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.OldLace;
            this.button4.Location = new System.Drawing.Point(1048, 381);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(285, 53);
            this.button4.TabIndex = 28;
            this.button4.Text = "Update";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // btnItemsBack
            // 
            this.btnItemsBack.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.btnItemsBack.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemsBack.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnItemsBack.Location = new System.Drawing.Point(1093, 93);
            this.btnItemsBack.Name = "btnItemsBack";
            this.btnItemsBack.Size = new System.Drawing.Size(285, 76);
            this.btnItemsBack.TabIndex = 29;
            this.btnItemsBack.Text = "Back";
            this.btnItemsBack.UseVisualStyleBackColor = false;
            this.btnItemsBack.Click += new System.EventHandler(this.btnItemsBack_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGray;
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1093, 193);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(285, 76);
            this.button1.TabIndex = 30;
            this.button1.Text = "MDetails";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtcid1
            // 
            this.txtcid1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcid1.Location = new System.Drawing.Point(513, 300);
            this.txtcid1.Name = "txtcid1";
            this.txtcid1.Size = new System.Drawing.Size(509, 45);
            this.txtcid1.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(252, 300);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 39);
            this.label4.TabIndex = 32;
            this.label4.Text = "Cashier ID";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Tan;
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.OldLace;
            this.button2.Location = new System.Drawing.Point(1048, 440);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(285, 53);
            this.button2.TabIndex = 33;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Tan;
            this.button5.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.OldLace;
            this.button5.Location = new System.Drawing.Point(1048, 499);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(285, 51);
            this.button5.TabIndex = 34;
            this.button5.Text = "Update";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::System_for_a_food_city.cs.Properties.Resources.cash1s;
            this.pictureBox2.Location = new System.Drawing.Point(12, 263);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(200, 272);
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::System_for_a_food_city.cs.Properties.Resources.super;
            this.pictureBox1.Location = new System.Drawing.Point(239, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(848, 246);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // Cashier_1_Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1373, 669);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtcid1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnItemsBack);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.txtCashier1Email);
            this.Controls.Add(this.txtCashier1Number);
            this.Controls.Add(this.txtcname1);
            this.Controls.Add(this.txteaddress1);
            this.Controls.Add(this.txtcno1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Cashier_1_Update";
            this.Text = "Cashier_1_Update";
            this.Load += new System.EventHandler(this.Cashier_1_Update_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label txtcno1;
        private System.Windows.Forms.Label txteaddress1;
        private System.Windows.Forms.TextBox txtcname1;
        private System.Windows.Forms.TextBox txtCashier1Number;
        private System.Windows.Forms.TextBox txtCashier1Email;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnItemsBack;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtcid1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
    }
}