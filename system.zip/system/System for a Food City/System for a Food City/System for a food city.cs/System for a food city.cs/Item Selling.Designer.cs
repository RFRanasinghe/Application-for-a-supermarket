﻿
namespace System_for_a_food_city.cs
{
    partial class Item_Selling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnCashierLogin = new System.Windows.Forms.Button();
            this.btnItemsellBack = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.V = new System.Windows.Forms.GroupBox();
            this.txtbalance = new System.Windows.Forms.TextBox();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.txtpayment = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.txtprice = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtiname = new System.Windows.Forms.ComboBox();
            this.txtdis = new System.Windows.Forms.TextBox();
            this.txtdiscount = new System.Windows.Forms.Label();
            this.txtQTY = new System.Windows.Forms.TextBox();
            this.txtquantity = new System.Windows.Forms.Label();
            this.txtItemID = new System.Windows.Forms.TextBox();
            this.txtid = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.txtname = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.V.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 271);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 39);
            this.label1.TabIndex = 3;
            this.label1.Text = "Cashier 1 Name";
            // 
            // btnCashierLogin
            // 
            this.btnCashierLogin.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCashierLogin.Location = new System.Drawing.Point(19, 119);
            this.btnCashierLogin.Name = "btnCashierLogin";
            this.btnCashierLogin.Size = new System.Drawing.Size(285, 76);
            this.btnCashierLogin.TabIndex = 8;
            this.btnCashierLogin.Text = "Item Details";
            this.btnCashierLogin.UseVisualStyleBackColor = true;
            this.btnCashierLogin.Click += new System.EventHandler(this.btnCashierLogin_Click);
            // 
            // btnItemsellBack
            // 
            this.btnItemsellBack.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemsellBack.Location = new System.Drawing.Point(12, 656);
            this.btnItemsellBack.Name = "btnItemsellBack";
            this.btnItemsellBack.Size = new System.Drawing.Size(285, 76);
            this.btnItemsellBack.TabIndex = 9;
            this.btnItemsellBack.Text = "Back";
            this.btnItemsellBack.UseVisualStyleBackColor = true;
            this.btnItemsellBack.Click += new System.EventHandler(this.btnItemsellBack_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(314, 656);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(285, 76);
            this.button1.TabIndex = 10;
            this.button1.Text = "Logout";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // V
            // 
            this.V.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.V.Controls.Add(this.txtbalance);
            this.V.Controls.Add(this.txttotal);
            this.V.Controls.Add(this.button3);
            this.V.Controls.Add(this.txtpayment);
            this.V.Controls.Add(this.label3);
            this.V.Controls.Add(this.button2);
            this.V.Controls.Add(this.txtprice);
            this.V.Controls.Add(this.label2);
            this.V.Controls.Add(this.txtiname);
            this.V.Controls.Add(this.txtdis);
            this.V.Controls.Add(this.txtdiscount);
            this.V.Controls.Add(this.txtQTY);
            this.V.Controls.Add(this.txtquantity);
            this.V.Controls.Add(this.txtItemID);
            this.V.Controls.Add(this.txtid);
            this.V.Controls.Add(this.button4);
            this.V.Controls.Add(this.txtname);
            this.V.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.V.Location = new System.Drawing.Point(725, 271);
            this.V.Name = "V";
            this.V.Size = new System.Drawing.Size(612, 436);
            this.V.TabIndex = 11;
            this.V.TabStop = false;
            this.V.Text = "Bill";
            // 
            // txtbalance
            // 
            this.txtbalance.Location = new System.Drawing.Point(279, 352);
            this.txtbalance.Name = "txtbalance";
            this.txtbalance.Size = new System.Drawing.Size(208, 30);
            this.txtbalance.TabIndex = 32;
            // 
            // txttotal
            // 
            this.txttotal.Location = new System.Drawing.Point(279, 273);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(208, 30);
            this.txttotal.TabIndex = 31;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(32, 352);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(152, 44);
            this.button3.TabIndex = 29;
            this.button3.Text = "Balance";
            this.button3.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtpayment
            // 
            this.txtpayment.Location = new System.Drawing.Point(279, 309);
            this.txtpayment.Name = "txtpayment";
            this.txtpayment.Size = new System.Drawing.Size(208, 30);
            this.txtpayment.TabIndex = 28;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(32, 310);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 39);
            this.label3.TabIndex = 27;
            this.label3.Text = "Payment";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(28, 267);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(127, 39);
            this.button2.TabIndex = 25;
            this.button2.Text = "Total";
            this.button2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtprice
            // 
            this.txtprice.Location = new System.Drawing.Point(279, 141);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(208, 30);
            this.txtprice.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 39);
            this.label2.TabIndex = 23;
            this.label2.Text = "Item price";
            // 
            // txtiname
            // 
            this.txtiname.FormattingEnabled = true;
            this.txtiname.Items.AddRange(new object[] {
            "Chocolate",
            "Milk",
            "Biscuit",
            "Ice-cream"});
            this.txtiname.Location = new System.Drawing.Point(279, 93);
            this.txtiname.Name = "txtiname";
            this.txtiname.Size = new System.Drawing.Size(208, 33);
            this.txtiname.TabIndex = 22;
            // 
            // txtdis
            // 
            this.txtdis.Location = new System.Drawing.Point(279, 181);
            this.txtdis.Name = "txtdis";
            this.txtdis.Size = new System.Drawing.Size(208, 30);
            this.txtdis.TabIndex = 19;
            // 
            // txtdiscount
            // 
            this.txtdiscount.AutoSize = true;
            this.txtdiscount.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdiscount.Location = new System.Drawing.Point(25, 174);
            this.txtdiscount.Name = "txtdiscount";
            this.txtdiscount.Size = new System.Drawing.Size(130, 39);
            this.txtdiscount.TabIndex = 18;
            this.txtdiscount.Text = "Discount";
            // 
            // txtQTY
            // 
            this.txtQTY.Location = new System.Drawing.Point(279, 222);
            this.txtQTY.Name = "txtQTY";
            this.txtQTY.Size = new System.Drawing.Size(208, 30);
            this.txtQTY.TabIndex = 15;
            this.txtQTY.TextChanged += new System.EventHandler(this.txtQTY_TextChanged);
            // 
            // txtquantity
            // 
            this.txtquantity.AutoSize = true;
            this.txtquantity.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtquantity.Location = new System.Drawing.Point(25, 213);
            this.txtquantity.Name = "txtquantity";
            this.txtquantity.Size = new System.Drawing.Size(134, 39);
            this.txtquantity.TabIndex = 14;
            this.txtquantity.Text = "Quantity";
            // 
            // txtItemID
            // 
            this.txtItemID.Location = new System.Drawing.Point(279, 42);
            this.txtItemID.Name = "txtItemID";
            this.txtItemID.Size = new System.Drawing.Size(208, 30);
            this.txtItemID.TabIndex = 13;
            // 
            // txtid
            // 
            this.txtid.AutoSize = true;
            this.txtid.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtid.Location = new System.Drawing.Point(21, 40);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(125, 39);
            this.txtid.TabIndex = 12;
            this.txtid.Text = "Item ID";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Aqua;
            this.button4.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(306, 385);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(300, 45);
            this.button4.TabIndex = 11;
            this.button4.Text = "ENTER";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // txtname
            // 
            this.txtname.AutoSize = true;
            this.txtname.Font = new System.Drawing.Font("Comic Sans MS", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(21, 93);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(163, 39);
            this.txtname.TabIndex = 4;
            this.txtname.Text = "Item Name";
            this.txtname.Click += new System.EventHandler(this.label2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::System_for_a_food_city.cs.Properties.Resources._out;
            this.pictureBox2.Location = new System.Drawing.Point(-4, 313);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(603, 337);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::System_for_a_food_city.cs.Properties.Resources.super;
            this.pictureBox1.Location = new System.Drawing.Point(356, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(869, 246);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Item_Selling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(1443, 743);
            this.Controls.Add(this.V);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnItemsellBack);
            this.Controls.Add(this.btnCashierLogin);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Item_Selling";
            this.Text = "Item_Selling";
            this.Load += new System.EventHandler(this.Item_Selling_Load);
            this.V.ResumeLayout(false);
            this.V.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnCashierLogin;
        private System.Windows.Forms.Button btnItemsellBack;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox V;
        private System.Windows.Forms.Label txtname;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label txtquantity;
        private System.Windows.Forms.TextBox txtItemID;
        private System.Windows.Forms.Label txtid;
        private System.Windows.Forms.TextBox txtdis;
        private System.Windows.Forms.Label txtdiscount;
        private System.Windows.Forms.ComboBox txtiname;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtprice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.TextBox txtpayment;
        private System.Windows.Forms.TextBox txtQTY;
        private System.Windows.Forms.TextBox txtbalance;
    }
}